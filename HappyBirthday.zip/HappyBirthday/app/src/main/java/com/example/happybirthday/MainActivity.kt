package com.example.happybirthday

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

//         val intent =  Intent( this,  MainActivity2::class.java)
//
//        startActivity(intent)
//        createBirthdayButton.setOnClickListener({
//
//        })


    }

    fun createBirthdayCard(view: View) {

        val name  = nameInput.editableText.toString()
        val customMessage = custom_message.editableText.toString()


        val intent =  Intent( this,  MainActivity2::class.java)
        intent.putExtra(MainActivity2.Name_Extra, name);
        intent.putExtra(MainActivity2.Msg_Extra, customMessage);
        startActivity(intent)

//        val name  = nameInput.editableText.toString()
//
//        Toast.makeText(this, "Name is $name", Toast.LENGTH_LONG).show();

    }


}