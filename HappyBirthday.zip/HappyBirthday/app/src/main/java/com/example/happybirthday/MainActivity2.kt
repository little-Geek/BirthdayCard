package com.example.happybirthday

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main2.*

class MainActivity2 : AppCompatActivity() {

     companion object{
        const val Name_Extra = "name_extra"
         const val Msg_Extra = "msg_extra"

     }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        val name = intent.getStringExtra(Name_Extra);
        val mymsg = intent.getStringExtra(Msg_Extra);

         birthdayGreeting.text = "Happy Birthday\n $name"
        customer_msg.text = " $mymsg"



    }
}